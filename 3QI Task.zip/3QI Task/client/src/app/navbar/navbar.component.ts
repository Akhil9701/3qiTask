import { Component, OnInit, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  localval: Observable<any>
  adminval: Observable<any>
  constructor(private router: Router) { }

  CheckLocalStore(): Observable<any> {
    return of(localStorage.getItem("employeeId"));
  }

  CheckLocalStoreadm(): Observable<any> {
    return of(localStorage.getItem("managerId")); 
  }

  logout() {
    localStorage.removeItem("employeeId");
    this.router.navigate(['home']);

    localStorage.removeItem("managerId")
    this.router.navigate(['home'])
  }

  ngOnInit() {

  }
  ngDoCheck() {
    this.CheckLocalStore().subscribe((data) => { this.localval = data })
    this.CheckLocalStoreadm().subscribe((data) => { this.adminval = data })
  }



}
