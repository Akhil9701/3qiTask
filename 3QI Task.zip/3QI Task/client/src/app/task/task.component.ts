import { Component, OnInit } from '@angular/core';
import { TaskService } from '../services/task.service';
import { Router } from '@angular/router';
import { task } from '../model/task';

@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {
  tasks:task
  constructor( private taskservice:TaskService,private router:Router) {
    this.tasks=new task();
   }
   Savetask(taskForm){
    if(taskForm.valid){
     console.log(JSON.stringify(this.tasks))
     this.taskservice.addTask(this.tasks).subscribe(
       (data)=>{console.log(data);
        alert(JSON.stringify(data))
        this.router.navigate(['home']) 
        }
      )
     }
  }


  ngOnInit() {
  }

}
