import { Component, OnInit } from '@angular/core';
import { TaskService } from '../services/task.service';
import { Router } from '@angular/router';
import { admin } from '../model/admin';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  aObj: admin;
  constructor(private taskservice:TaskService,private router:Router) {
    this.aObj = new admin();
  }

  btnfun(ui, psw) {
    this.taskservice.adminlogin(ui, psw).subscribe((data) => {
      if (data.length > 0) {
        alert('Login succesfull.....')
        localStorage.setItem('managerId', this.aObj.managerId)
        this.router.navigate(['home'])
      }
    })
  }

  ngOnInit(){

  }
}
