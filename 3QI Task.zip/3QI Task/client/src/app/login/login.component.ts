import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskService } from '../services/task.service';
import { register } from '../model/register';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: register
  constructor(private rt: Router, private taskservice: TaskService) {
    this.login = new register();

  }

  btnLoginClick(u, p) {
    this.taskservice.CheckLogin(u, p).subscribe((data) => {
      if (data.length > 0) {
        alert('Login succesfull.....')
        localStorage.setItem("employeeId", u)
        this.rt.navigate(['home'])
      }
      else {
        alert('Invalid User...You need to signup')
      }
    })
  }

  ngOnInit() {

  }
}
