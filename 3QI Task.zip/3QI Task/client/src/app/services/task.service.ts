import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable } from 'rxjs';
import { task } from '../model/task';
@Injectable({
  providedIn: 'root'
})
export class TaskService {

  private myurll: string = "http://localhost:4600"

  constructor(private http: HttpClient) { }

  registerUser(register) {
    return this.http.post(this.myurll + '/register', register);
  }
  CheckLogin(ui: string, p: string): Observable<any> {

    return this.http.get(this.myurll + '/register/' + ui + '/' + p, { responseType: 'json' });
  }
  addTask(tObj: task): Observable<any> {
    const hdrOptions = {
      headers: new HttpHeaders({ 'content-type': 'application/json' })
    }
    return this.http.post(this.myurll + '/task', JSON.stringify(tObj), hdrOptions)
  }
  getTaskDetails(): Observable<any> {
    return this.http.get(this.myurll + '/task', { responseType: 'json' })
  }
  adminlogin(id, pwd): Observable<any> {
    return this.http.get(this.myurll + '/adminlogin/' + id + '/' + pwd, { responseType: 'json' })
  }
}
