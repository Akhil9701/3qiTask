export class register{
    employeeId:number;
    employeeName:string;
    email:string;
    password:string
}