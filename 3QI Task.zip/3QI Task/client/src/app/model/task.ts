export class task{
    taskName:string;
    taskDate:string;
    taskTime:string;
    employeeId:number;
}