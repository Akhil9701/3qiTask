export class taskdetail{
    EmployeeId:number;
    EmployeeName:string;
    taskName:string;
    taskDate:string;
    taskTime:string;
}