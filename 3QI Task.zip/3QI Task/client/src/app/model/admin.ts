export class admin{
    managerId:string;
    password:string
}