import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TaskService } from '../services/task.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {


  register: FormGroup;
  submitted = false;
  resp;
  constructor(private taskservice:TaskService,private router:Router,private formBuilder:FormBuilder) { }

  ngOnInit() {
    this.register = this.formBuilder.group({
      employeeId:['',[Validators.required]],
      employeeName: ['', [Validators.required, Validators.minLength(4)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }
// convenience getter for easy access to form fields
get f() { return this.register.controls; }
onSubmit() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.register.invalid) {
    return;
  }

  this.taskservice.registerUser(this.register.value).subscribe(
    (response) => {
      this.resp = response;
      // alert(this.resp.message);
      console.log(this.resp);
      if (this.resp.status == true) {
        this.router.navigate(['/login']);
      }
      else {
        alert(this.resp.message);
        // this.register.reset();
        this.register.controls['email'].reset()

      }
    }
  )
}
  

}
