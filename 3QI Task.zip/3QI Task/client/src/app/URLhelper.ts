export class URLHelper{
    
    static urls={
        "home":true,
        "login":true,
        "register":true,
        "logout":false,
        "products":false,
        "addproducts":false,
    }
}