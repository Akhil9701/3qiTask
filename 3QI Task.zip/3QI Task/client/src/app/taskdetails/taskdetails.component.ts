import { Component, OnInit } from '@angular/core';
import { taskdetail } from '../model/taskdetail';
import { TaskService } from '../services/task.service';

@Component({
  selector: 'app-taskdetails',
  templateUrl: './taskdetails.component.html',
  styleUrls: ['./taskdetails.component.css']
})
export class TaskdetailsComponent implements OnInit {
  tObj:any=[]=[];
  constructor(private taskservice:TaskService) { 
    // this.tObj=new taskdetail();
  }

  ngOnInit() {
    this.taskservice.getTaskDetails().subscribe((data)=>{
      this.tObj=data
      console.log(this.tObj)
    })
  }

}
