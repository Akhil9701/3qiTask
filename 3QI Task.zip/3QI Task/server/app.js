var fs = require('fs')
var path = require('path')
var bodyparser = require('body-parser')
var express = require('express')
var promise = require('bluebird')

var app = express();
var options = { promiseLib: promise }

var pgp = require('pg-promise')(options)
var cs = 'postgres://postgres:root1@localhost:5432/3qitask'

var db = pgp(cs)

app.set('port', process.env.PORT || 4600)

app.use(bodyparser.json({ limit: "50mb" }));
app.use(bodyparser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }));


app.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');


    res.setHeader('Access-Control-Allow-Methods', '*');


    res.setHeader('Access-Control-Allow-Headers', '*');


    res.setHeader('Access-Control-Allow-Credentials', true);


    next();
});

app.get('/', (req, res) => {
    res.send('Database coinnectivity Ex.....')
})

//                                                  Register API:

app.get('/register', (req, res, next) => {
    db.any('select * from  register').then(
        (data) => {
            res.send(data)
        })
})

app.post('/register', (req, res, next) => {
    var i = parseInt(req.body.employeeId)
    var n = req.body.employeeName
    var e = req.body.email
    var pw = req.body.password
    db.any('insert into register values($1,$2,$3,$4)', [i, n, e, pw]).then(
        (data) => {
            res.send({ 'message': 'Registration successfull' })
        }
    )
})

app.get('/register/:employeeId/:password', (req, res, next) => {
    var ei = req.params.employeeId
    var p = req.params.password
    console.log(ei + " " + p);
    db.any('select * from register where employeeId=$1 and password=$2', [ei, p])
        .then((data) => {
            res.send(data)
        })

})


//                                                  Task API:




app.post('/task', (req, res, next) => {
    var n = req.body.taskName
    var d = req.body.taskDate
    var t = req.body.taskTime
    var ei = req.body.employeeId
    db.any('insert into task values($1,$2,$3,$4)', [n, d, t, ei]).then(
        (data) => {
            res.send({ 'message': 'Saved Successssssss...' })
        }
    )
})


app.get('/task', (req, res, next) => {
    db.any('select * from task').then(
        (data) => {
            res.send(data)
        })
})


// Display the task details by employee Id

app.get('/data', (req, res, next) => {
    var ei = req.params.employeeId
    db.any("select register.employeeId,employeeName,taskName,taskDate,taskTime from register inner join task on task.employeeId=register.employeeId", ei).then((data) => {
        res.send(data)
    })
})





//admin login

app.get('/adminlogin/:aid/:pwd',(req,res,next)=>{
    var id = req.params.aid
    var p =req.params.pwd

    db.any("select * from admin where managerId =$1 and password = $2",[id,p]).then((data)=>{
        res.send(data)
    })

})










app.listen(app.get('port'), (err) => {
    if (err)
        console.log('server not started')
    else
        console.log('server Started at  : http://localhost:4600')
})